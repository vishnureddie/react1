package com.appstekcorp.portlet.userProfile.portlet.util;

import com.appstekcorp.norka.portlet.userprofile.constants.UserProfilePortletKeys;
import com.jhansi.citizenTables.exception.NoSuchCitizenRegisterOtpException;
import com.jhansi.citizenTables.model.CitizenRegisterOtp;
import com.jhansi.citizenTables.model.impl.CitizenRegisterOtpImpl;
import com.jhansi.citizenTables.service.CitizenRegisterOtpLocalServiceUtil;
import com.jhansi.citizenTables.service.CitizensLocalServiceUtil;
import com.jhansi.citizenTables.service.constants.CustomTablePortletKeys;
import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.mail.kernel.model.MailMessage;
import com.liferay.mail.kernel.service.MailServiceUtil;
import com.liferay.portal.kernel.captcha.CaptchaException;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.PropsUtil;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Random;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.w3c.dom.CharacterData;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class CustomUtil {
	public static JSONObject sentOtp(String mobileNumber,int otp,int requestType)throws CaptchaException, IOException {
		 
		JSONObject jsonObj = JSONFactoryUtil.createJSONObject();
		JSONObject mainJsonObj = JSONFactoryUtil.createJSONObject();

		
		_log.info("opt>>>"+otp);
		jsonObj.put("OTP",otp);
		jsonObj.put("mobileNumber",mobileNumber); 
		
		String environment = PropsUtil.get("jhansi.site.environment");
		System.out.println("environment.. "+environment);
		String message="";
		 String templateid="";
		String requestTypeMessage="";
		if(requestType==1) {
			requestTypeMessage="Registration";
			templateid=CustomTablePortletKeys.REGISTER_JSCL_TEMPLATE_ID;
		}
		else if(requestType==2) {
			requestTypeMessage="Update Profile";
			templateid=CustomTablePortletKeys.UPDATE_PROFILE_JSCL_TEMPLATE_ID;
		}
		else if(requestType==3) {
			requestTypeMessage="Forgot Password";
			templateid=CustomTablePortletKeys.FORGOT_PASSWORD_JSCL_TEMPLATE_ID;
		}
		
		if(environment.equalsIgnoreCase("PROD")){
			message="OTP to "+requestTypeMessage+" in JSCL Application is "+otp+". Do not share this OTP to any one for security reasons.";
		}else{
			message="OTP to "+requestTypeMessage+" in JSCL Application is "+otp+". Do not share this OTP to any one for security reasons.";
		}
	 
		try {
			mainJsonObj=CitizensLocalServiceUtil.sendSMS(mobileNumber, message,templateid,true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mainJsonObj.put("data", jsonObj);
	   return mainJsonObj;
  }
	
	
	public static void manageSmsInfo(String mobileNumber, int otp, int requestTyp, JSONObject response) {
		boolean newRecord = true;
		int smsCount = 1;
		String status = null;
		String code = null;
		String reason = null;
		String clientSMSId = null;
		String messageId = null;
		CitizenRegisterOtp otpOnj = new CitizenRegisterOtpImpl();

		try {
			otpOnj = CitizenRegisterOtpLocalServiceUtil.findByMobileNumberAndRequestType(mobileNumber, requestTyp);
			newRecord = false;
			smsCount = otpOnj.getSmsCount() + 1;

		} catch (Exception e) {

			_log.info("record not existed");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		_log.info("response... " + response);
		if (newRecord) {
			long otpEntityId = CounterLocalServiceUtil.increment(CitizenRegisterOtp.class.getName());
			otpOnj.setOtpId(otpEntityId);

		}
		otpOnj.setModifiedDate(new Date());
		otpOnj.setSmsCount(smsCount);
		otpOnj.setRequestType(requestTyp);
		otpOnj.setMobileNumber(mobileNumber);
		otpOnj.setOtp(otp);
		// otpOnj.setResponse(response);
		otpOnj.setStatus(status);
		otpOnj.setCode(code);
		otpOnj.setReason(reason);
		otpOnj.setClientSMSId(clientSMSId);
		otpOnj.setMessageId(messageId);
		otpOnj.setVerified(false);
		otpOnj.setModifiedDate(new Date());
		if (newRecord) {
			CitizenRegisterOtpLocalServiceUtil.addCitizenRegisterOtp(otpOnj);
		} else {
			CitizenRegisterOtpLocalServiceUtil.updateCitizenRegisterOtp(otpOnj);
		}
	}
	
	//send email 
	 public static void sendEmail(String to, String subject, String body) {
		 InternetAddress fromAddress = null;
			InternetAddress toAddress = null;
		
			try {
				fromAddress = new InternetAddress(UserProfilePortletKeys.EMAIL_FROM_ADDRESS);
				toAddress = new InternetAddress(to);
				MailMessage mailMessage = new MailMessage();
				
				mailMessage.setTo(toAddress);
				mailMessage.setFrom(fromAddress);
				mailMessage.setSubject(subject);
				mailMessage.setBody(body);
				mailMessage.setHTMLFormat(true);
				MailServiceUtil.sendEmail(mailMessage);
				_log.info("Email sent to:"+toAddress);
			} catch (AddressException e) {
				e.printStackTrace();
			}
	 }
	public static int generateOtp() {
		String time=String.valueOf(System.currentTimeMillis()).trim();
		String subString;
		Random rand = new Random();
		subString = String.format("%04d", rand.nextInt(10000));
		//_log.info("otpp : "+subString);
		int otp = Integer.parseInt(subString.trim());
		if(otp > 999 && otp < 10000) {
			return otp;
		}
		else {
			return generateOtp();
		}
	}
	public static boolean otpValidation(String mobileNumber,int otp,int requestType) throws NoSuchCitizenRegisterOtpException {
		CitizenRegisterOtp citizenRegisterOtp=null;
			boolean status=false;
			int orgOTP=0;
			  citizenRegisterOtp = CitizenRegisterOtpLocalServiceUtil.findByMobileNumberAndRequestType(mobileNumber, requestType);
			  if(citizenRegisterOtp!=null) {
				  orgOTP= citizenRegisterOtp.getOtp();
				  if(orgOTP==otp) {
					  citizenRegisterOtp.setStatus("success");
					  citizenRegisterOtp.setVerified(true);
					  CitizenRegisterOtpLocalServiceUtil.updateCitizenRegisterOtp(citizenRegisterOtp);
					  status=true;
  
					    }
					  
				  }  
		return status;
	}
	private static final Log _log = LogFactoryUtil.getLog(CustomUtil.class.getName());
	 public static String getCharacterDataFromElement(Element e) {
		    Node child = e.getFirstChild();
		    if (child instanceof CharacterData) {
		       CharacterData cd = (CharacterData) child;
		       return cd.getData();
		    }
		    return "?";
		  }
	 
	 
	 
	 public static String getMaskedMobileNumber(String phoneNumber) {
		 
		 
		 if(phoneNumber!=null && !phoneNumber.trim().equals("")  )
		 {			 
			 if(!phoneNumber.toLowerCase().contains("nil"))
			 {
				 String firstNumber ="";
				 String restNumber ="";

				 if(phoneNumber.length()>8)
				 {
					 firstNumber = phoneNumber.substring(0, 4);				
				 }
				 else if(phoneNumber.length()==8)
				 {
					 firstNumber = phoneNumber.substring(0, 2);				
				 }
				 restNumber = phoneNumber.substring(firstNumber.length(),phoneNumber.length());
				 phoneNumber=	firstNumber+restNumber.replaceAll("\\d(?=(?:\\D*\\d){3})", "*");
			 }
			 else
			 {
				 phoneNumber ="0";
			 }
		 }
		
		 

		 return phoneNumber;
	 }
}
