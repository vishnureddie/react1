package com.appstekcorp.norka.portlet.userprofile.portlet;

import com.appstekcorp.norka.portlet.userprofile.constants.UserProfilePortletKeys;
import com.appstekcorp.portlet.userProfile.portlet.util.CustomUtil;
import com.jhansi.citizenTables.exception.NoSuchCitizenRegisterOtpException;
import com.jhansi.citizenTables.model.Citizens;
import com.jhansi.citizenTables.model.Mohallas;
import com.jhansi.citizenTables.model.impl.CitizensImpl;
import com.jhansi.citizenTables.service.CitizensLocalServiceUtil;
import com.jhansi.citizenTables.service.MohallasLocalServiceUtil;
import com.jhansi.citizenTables.service.constants.CustomTablePortletKeys;
import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.captcha.CaptchaException;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.OrderFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.CompanyConstants;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.search.Indexer;
import com.liferay.portal.kernel.search.IndexerRegistryUtil;
import com.liferay.portal.kernel.security.pwd.PasswordEncryptorUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.Base64;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.taglib.ui.JournalArticleTag;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.PortletSession;
import javax.portlet.ProcessAction;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;

/**
 * @author AppsTek Corp
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/custom.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.init-param.template-path=/", "javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + UserProfilePortletKeys.UserProfile, "javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class UserProfilePortlet extends MVCPortlet {

	@ProcessAction(name = "updatePassword")
	public void updatePassword(ActionRequest actionRequest, ActionResponse actionResponse) {
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		_log.info(":::::::::::::calling updatePassword::::::::::::::::");
		String current = ParamUtil.getString(actionRequest, "current", "");
		String password1 = ParamUtil.getString(actionRequest, "password1", "");
		String password2 = ParamUtil.getString(actionRequest, "password2", "");
		String errorKey = "";

		try {
			String authType = themeDisplay.getCompany().getAuthType();
			String login = "";
			/**
			 * authType can be of three types. Therefore based on authType login
			 * can email address or screen name or user id of the logged in user
			 */
			if (authType.equals(CompanyConstants.AUTH_TYPE_EA)) {
				login = themeDisplay.getUser().getEmailAddress();
			} else if (authType.equals(CompanyConstants.AUTH_TYPE_SN)) {
				login = themeDisplay.getUser().getScreenName();
			} else if (authType.equals(CompanyConstants.AUTH_TYPE_ID)) {
				login = String.valueOf(themeDisplay.getUser().getUserId());
			}

			/**
			 * The method authenticateForBasic returns userId of the logged in
			 * user if all the parameters in the method are correct. Otherwise
			 * it will return 0. Notice the if condition
			 */

			long userId = UserLocalServiceUtil.authenticateForBasic(themeDisplay.getCompanyId(), authType, login,
					current);
			if (themeDisplay.getUserId() != userId) {
				errorKey = "invalid-current-password";
				throw new Exception("Invalid current password.");
			}
			if (!password1.equals(password2)) {
				errorKey = "confirm-new-password";
				throw new Exception("Please confirm new password.");
			}
			 String encrypedPassword=PasswordEncryptorUtil.encrypt(password1);
			  User user= UserLocalServiceUtil.fetchUser(userId);
			  if(user!=null) {
				  user.setPassword(encrypedPassword); 
	 			  UserLocalServiceUtil.updateUser(user);
			  }
		} catch (PortalException e) {
			_log.error(e.getMessage(), e);
		} catch (SystemException e) {
			_log.error(e.getMessage(), e);
		} catch (Exception e) {
			_log.error(e.getMessage(), e);
		}

		if (Validator.isNull(errorKey)) {
			SessionMessages.add(actionRequest, "password-update-success");
		} else {
			SessionErrors.add(actionRequest, errorKey);
		}

	}

	@ProcessAction(name = "changePhoneNumber")
	public void updateCitizenProfile(ActionRequest actionRequest, ActionResponse actionResponse) {
		_log.info(":::::::::::::calling phone number::::::::::::::::");
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		 SimpleDateFormat DbDataFormate=new SimpleDateFormat("yyyy-MM-dd");
		String noEmailDomain = "@noemail.com";
		String screenName = ParamUtil.getString(actionRequest, "screenName");
		String emailAddress = ParamUtil.getString(actionRequest, "emailAddress");
        _log.info("screenName>>>>>>."+screenName);
		String firstName = ParamUtil.getString(actionRequest, "firstName");
		String middleName = ParamUtil.getString(actionRequest, "middleName");
		String lastName = ParamUtil.getString(actionRequest, "lastName");
		_log.info("firstName>>>>>>."+firstName);
		_log.info("lastName>>>>>>."+lastName);
		long mohallaId = ParamUtil.getLong(actionRequest, "mohallas");
		long wardId = ParamUtil.getLong(actionRequest, "ward");
		String address = ParamUtil.getString(actionRequest, "address");
		int gender = ParamUtil.getInteger(actionRequest, "gender");
		String mobileNumber = screenName;
		 
		String aadhaarNumber = ParamUtil.getString(actionRequest, "aadhaarNumber");
		String panNumber = ParamUtil.getString(actionRequest, "panNumber");
		int age= ParamUtil.getInteger(actionRequest, "age");
		//int otp= ParamUtil.getInteger(actionRequest, "otp");
		boolean otpValidate=true;
		String birthDate = ParamUtil.getString(actionRequest, "birthDate");
		long userId = themeDisplay.getUserId();
		User user = null;
		String existingScreenName="";
		 
        boolean flag=true;
		 
		 
		 String[] specialChars= CustomTablePortletKeys.BACKEND_NOT_ALLOWED_SPECIAL_CHARACTERS;
		 for (String item : specialChars) {
			 if (Validator.isNotNull(firstName)  && firstName.contains(item)) {
		        	SessionErrors.add(actionRequest, "firstName.errorMsg.missing");
					flag =false;
		        }
		        if (Validator.isNotNull(lastName) && lastName.contains(item)) {
		        	SessionErrors.add(actionRequest, "lastName.errorMsg.missing");
					flag =false;
		        } 
		        if (Validator.isNotNull(emailAddress) && emailAddress.contains(item)) {
		        	SessionErrors.add(actionRequest, "emailAddress.errorMsg.missing");
					flag =false;
		        }
                if (Validator.isNotNull(birthDate) && birthDate.contains(item)) {
                	SessionErrors.add(actionRequest, "birthDate.errorMsg.missing");
    				flag =false;
		        }
                if (Validator.isNotNull(aadhaarNumber) && aadhaarNumber.contains(item)) {
                	SessionErrors.add(actionRequest, "aadhaarNumber.errorMsg.missing");
    				flag =false;
		        }
                if (Validator.isNotNull(panNumber) && panNumber.contains(item)) {
                	SessionErrors.add(actionRequest, "panNumber.errorMsg.missing");
    				flag =false;
		        }
                if (Validator.isNotNull(address) && address.contains(item)) {
                	SessionErrors.add(actionRequest, "address.errorMsg.missing");
    				flag =false;
		        }
                if (Validator.isNotNull(screenName) && screenName.contains(item)) {
                	SessionErrors.add(actionRequest, "screenName.errorMsg.missing");
    				flag =false;
		        }
                
		    }
		if(flag) {
		
		 
		try {
			user = UserLocalServiceUtil.getUser(userId);
			existingScreenName=user.getScreenName();
		} catch (PortalException e1) {
			System.out.println("Exception 2 >>>");
			e1.printStackTrace();
		}
			if(user!=null) {	 
         	 
			 try {
         		user.setFirstName(firstName);
         		user.setLastName(lastName);
         		user.setMiddleName(middleName);
         		System.out.println("user.getScreenName>>>"+user.getScreenName());
         		
         		//user.setScreenName(screenName);
 			        if(emailAddress.isEmpty()) {
 			        	System.out.println("EMAIL IS EMPTY>>>");
     				//	Random random = new Random(7289374);
     					//int randNum = random.nextInt();
     					emailAddress = screenName + noEmailDomain;
     				}
 			        else {
 			        	 user.setEmailAddress(emailAddress);
 			        	System.out.println("EMAIL IS NOt EMPTY>>>"+user.getEmailAddress());
 			        }
			       //}
 			       System.out.println("EMAIL address>>>"+user.getEmailAddress());
			      
 			      user=UserLocalServiceUtil.updateUser(user);
 			      
 			      
 			     Indexer<User> indexUser= IndexerRegistryUtil.nullSafeGetIndexer(User.class);

 			    indexUser.reindex(user);
 			      
			       System.out.println("Updated Successfully >>>"+user.getFirstName());
				} catch (Exception e) {
					System.out.println("Exception 1 >>>");
					_log.error("Exception in date conversion:" + e.getMessage());
				}
               
			}
		Citizens citizens=null;
		 try {
           citizens=CitizensLocalServiceUtil.findByuserId(userId);
		 }
		 catch(Exception e) {
			 System.out.println("NO record with Citizens Failed>>>");
			 e.getMessage();
		 }
		 try {
		 if(citizens!=null) {
        	 _log.info("citizens record exist");
        	citizens.setAadhaarNumber(aadhaarNumber);
        	citizens.setPanNumber(panNumber);
        	citizens.setWardId(wardId);
        	citizens.setGender(gender); 
        	citizens.setMohallaId(mohallaId);
        	if(birthDate!="") {
        		Date dob=null;
				try {
					dob = DbDataFormate.parse(birthDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	citizens.setDateofBirth(dob);
        	}
        	citizens.setAddress(address);
        	citizens.setAge(age);
        	
		 CitizensLocalServiceUtil.updateCitizens(citizens);
		 System.out.println("updateCitizens Success>>>");
        }
        else {
        	 _log.info("enter to create new citizens record");
        		Date dtBirth=null;
        	try{
        	
        		if(birthDate!=null) {
        		  SimpleDateFormat simpledate=new SimpleDateFormat("yyyy-MM-dd");
			          dtBirth=simpledate.parse(birthDate);
        		}
        	}catch(Exception e){
				 _log.info("citizens insert failed");
				_log.info("error"+e);
			}
        		
				 citizens =new CitizensImpl();
				long entryId= CounterLocalServiceUtil.increment(Citizens.class.getName());
				citizens.setEntryId(entryId);
				citizens.setWardId(wardId);
				citizens.setMohallaId(mohallaId);
				citizens.setAddress(address);
				citizens.setUserId(userId);
				citizens.setAadhaarNumber(aadhaarNumber);
				citizens.setPanNumber(panNumber);
				citizens.setMobileNumber(mobileNumber);
				citizens.setAge(age);
				citizens.setGender(gender);
				citizens.setDateofBirth(dtBirth);
				CitizensLocalServiceUtil.addCitizens(citizens);
				 _log.info("citizens record created");
			 
        }
		 }
		 catch (Exception e) {
			 e.getMessage();
			// TODO: handle exception
		}
		}
		else {
			
		}
		
		/*
		 * if(!existingScreenName.trim().equals(screenName.trim())) {
		 * 
		 * _log.info("existingScreenName>>>>>."+existingScreenName);
		 * _log.info("screenName>>>>>."+screenName); PortletSession session =
		 * actionRequest.getPortletSession(true); session.setAttribute("screenName",
		 * screenName); session.setAttribute("emailAddress", emailAddress);
		 * session.setAttribute("userId", userId); actionRequest.setAttribute("userId",
		 * themeDisplay.getUserId()); String cCode ="+91";
		 * _log.info("sending otp c code: "+cCode); int otp = CustomUtil.generateOtp();
		 * _log.info("otp "+otp); //if(CitizenLoginPortletKeys.ENABLE_OTP){ JSONObject
		 * response=null; try { response = CustomUtil.sentOtp(mobileNumber,otp,2); }
		 * catch (CaptchaException | IOException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } //if(!response.equalsIgnoreCase("fail")) {
		 * CustomUtil.manageSmsInfo(mobileNumber,otp,response); //}
		 * actionResponse.setRenderParameter(UserProfilePortletKeys.CMD,
		 * UserProfilePortletKeys.CMD_CREATE_USER);
		 * actionResponse.setRenderParameter("mvcPath", "/otp.jsp"); }
		 */

	}
	
	
	public void mobileUpdateOptvalidate(ActionRequest actionRequest, ActionResponse actionResponse) {
		_log.info(":::::::::::::calling phone number::::::::::::::::");
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String noEmailDomain = "@noemail.com";
		 
		int otp = ParamUtil.getInteger(actionRequest, "otp");
		PortletSession session = actionRequest.getPortletSession(false);
		String screenName = (String)session.getAttribute("screenName");
		String mobileNumber = screenName;
		String emailAddress = (String)session.getAttribute("emailAddress");
		long userId=themeDisplay.getUserId();
		
		boolean validOtp=false;
		try {
			validOtp = CustomUtil.otpValidation(mobileNumber, otp,2);
		} catch (NoSuchCitizenRegisterOtpException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if(validOtp) {
		try {
		   User user=UserLocalServiceUtil.fetchUser(userId);
		   if(user!=null) {
			   user.setScreenName(screenName);
			   UserLocalServiceUtil.updateUser(user);
		   }
		   Citizens citizens=CitizensLocalServiceUtil.findByuserId(userId);
		   //citizens.setMobileNumber(screenName);
		   CitizensLocalServiceUtil.updateCitizens(citizens);
		}
		catch(Exception e) {
			
		}
		actionResponse.setRenderParameter("mvcPath", "/view.jsp");
		}
		else {
			SessionErrors.add(actionRequest, "wrongOtp");
			actionResponse.setRenderParameter("mvcPath", "/otp.jsp");
		}
			}

	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
		String cmd = ParamUtil.getString(resourceRequest, "cmd");
		JSONObject jsonUser = JSONFactoryUtil.createJSONObject();
		PrintWriter out = resourceResponse.getWriter();
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
		if (cmd.equalsIgnoreCase("chnageProPic")) {

			_log.info(":::::::::::::calling profile Photo::::::::::::::::");
			String profilePicSrc = ParamUtil.getString(resourceRequest, "imgSrc");
			String[] imgD = profilePicSrc.split(",");
			byte[] imgData = Base64.decode(imgD[1]);

			try {
				UserLocalServiceUtil.updatePortrait(themeDisplay.getUserId(), imgData);
			//	MultiViewportUI.MPool.classclear();
				CacheRegistryUtil.clear();
				jsonUser.put("isValidImg", "true");
				_log.info("updated ");
			} catch (PortalException e) {
				jsonUser.put("isValidImg", "false");
				e.printStackTrace();
			}
			_log.info(jsonUser.toString());
			out.println(jsonUser.toString());
		}
		else if(cmd.equalsIgnoreCase("EmailAddressValidation")) {
			  long currentUserId = ParamUtil.getLong(resourceRequest, "currentUserId");
			  String emailAddress = ParamUtil.getString(resourceRequest, "emailAddress");
			    out = resourceResponse.getWriter();
			  _log.info("currentUserId>>"+currentUserId);
			  _log.info("emailAddress>>"+emailAddress);
					try {
						User userData=UserLocalServiceUtil.getUserByEmailAddress(themeDisplay.getCompanyId(), emailAddress);
						if(userData.getUserId()==currentUserId) {
							 jsonUser.put("emailExist", "false");
						}
						else {
							 jsonUser.put("emailExist", "true");
						}
					}
                 catch (SystemException e) {
                 	jsonUser.put("emailExist", "false");
					_log.info(e.getMessage());
				} 
				catch (PortalException e) {
					jsonUser.put("emailExist", "false");
					_log.info(e.getMessage());
				}
					out.println(jsonUser.toString());
		}
		else if(cmd.equalsIgnoreCase("screenNameValidation")) {
			  String screenName = ParamUtil.getString(resourceRequest, "screenName");
			  long currentUserId = ParamUtil.getLong(resourceRequest, "currentUserId");
			  _log.info("screenName>>>>>>>"+screenName);
			  _log.info("currentUserId>>>>>>>"+currentUserId);
					User userData=null;
					try {
						 userData=UserLocalServiceUtil.getUserByScreenName(themeDisplay.getCompanyId(), screenName);
						 if (userData != null) {
							 _log.info("step 1>>>>>>>");
								 if(userData.getUserId()==currentUserId) {
									 _log.info("step 2>>>>>>>");
									 jsonUser.put("screenNameExist", "false");
								}
								else {
									 jsonUser.put("screenNameExist", "true");
								}	 
							 } 
						     else {
						    	 _log.info("step 3>>>>>>>");
							     jsonUser.put("screenNameExist", "false");
							 }
					  }catch (PortalException e) {
						  jsonUser.put("screenNameExist", "false");
						e.printStackTrace();
						_log.info(e.getMessage());
					  }
				     catch (SystemException e) {
							jsonUser.put("screenNameExist", "false");
							e.printStackTrace();
							_log.info(e.getMessage());
						}
					//try {
					      // out = resourceResponse.getWriter();
						   out.println(jsonUser.toString());
					 
					  // _log.info("=="+jsonUser.toString());
		  }
		  else if(cmd.equalsIgnoreCase("getmahallas")) {
			  long wardId = ParamUtil.getLong(resourceRequest, "wardId");
			  
				try {
				              JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
				              DynamicQuery dynamicQuery = null; 
								dynamicQuery = MohallasLocalServiceUtil.dynamicQuery();
		                        dynamicQuery.add(RestrictionsFactoryUtil.eq("languageId", "en_US")); 
		                        dynamicQuery.add(RestrictionsFactoryUtil.eq("wardId", wardId)); 
								dynamicQuery.addOrder(OrderFactoryUtil.asc("mohallaName"));
								List<Mohallas> mohallasList=MohallasLocalServiceUtil.dynamicQuery(dynamicQuery, 0, MohallasLocalServiceUtil.getMohallasesCount());
		 	        	 		_log.info("mohallasList.size>>"+mohallasList.size());
								for(Mohallas data:mohallasList) {
									JSONObject jsonOb = JSONFactoryUtil.createJSONObject();
									jsonOb.put("id", data.getMohallaId());
									String str = data.getMohallaName();
					                String words[]=str.split("\\s");
					                String capitalizeStr="";
					                for(String word:words){
					                    String firstLetter=word.substring(0,1);
					                    String remainingLetters=word.substring(1).toLowerCase();
					                    capitalizeStr+=firstLetter.toUpperCase()+remainingLetters+" ";
					                }
									jsonOb.put("name",capitalizeStr);
									jsonArray.put(jsonOb); 
								}
								System.out.println("jsonArray length"+jsonArray.length());
							PrintWriter writer = resourceResponse.getWriter();
							writer.print( jsonArray.toJSONString());
					} catch (Exception e) {
						_log.info(e.getMessage());
					}
		  }
		  else if(cmd.equalsIgnoreCase("sendOTP")) {
			  JSONObject reponseOtp = JSONFactoryUtil.createJSONObject();
			  jsonUser = JSONFactoryUtil.createJSONObject();
			  String userid = ParamUtil.getString(resourceRequest , "userid");
			  String mobileNumber = ParamUtil.getString(resourceRequest, "mobileNumber").trim();
			  
			  _log.info("userid>>>>>>>"+userid);
			  _log.info("mobileNumber>>>>>>>"+mobileNumber); 
			  int otp = 0; 
			  User userData=null;   
			   boolean screenNameExist=false;
			   jsonUser.put("sendSMS", "false");
				try {
					 userData=UserLocalServiceUtil.getUserByScreenName(themeDisplay.getCompanyId(), mobileNumber);
					 if (userData != null) {
						   jsonUser.put("screenNameExist", "true");
						   screenNameExist=true;
						 } else {
						    jsonUser.put("screenNameExist", "false");
						 }
				  }catch (PortalException e) {
					  jsonUser.put("screenNameExist", "false");
					e.printStackTrace();
				  }
					catch (SystemException e) {
						jsonUser.put("screenNameExist", "false");
						e.printStackTrace();
					}
			  
			  if(!screenNameExist) { 
					  otp = CustomUtil.generateOtp();
					  try {
						  reponseOtp=CustomUtil.sentOtp(mobileNumber,otp,2);
					  } catch (Exception e1) {
						  // TODO Auto-generated catch block
						  e1.printStackTrace();
					  }
					  
					  _log.info("reponseOtp>>>"+reponseOtp);
	 
						  CustomUtil.manageSmsInfo(mobileNumber,otp,2,reponseOtp);
						  
						  jsonUser.put("sendSMS", "true");
			  }
			  out=null;
			  try {
				  out = resourceResponse.getWriter(); 
				  out.println(jsonUser.toString());
				  out.flush();
				  out.close();
			  } catch (IOException e) { 
				  e.printStackTrace();
			  }

			  _log.info("=="+jsonUser.toString());
		  }

	}

	private Log _log = LogFactoryUtil.getLog(UserProfilePortlet.class.getName());

}
