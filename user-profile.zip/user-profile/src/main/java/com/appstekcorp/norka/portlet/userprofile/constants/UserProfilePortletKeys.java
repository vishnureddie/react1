package com.appstekcorp.norka.portlet.userprofile.constants;

/**
 * @author AppsTek Corp
 */
public class UserProfilePortletKeys {

	public static final String UserProfile = "userprofile";
	public static final String NorkaLogin = "norkalogin";
	public static final long MOBILE_NUMBER_TYPE = 11008L;
	public static final long JHANSI_SMART_CITY_GROUP_ID = 35887L;
	public static final String CMD = "cmd";
	public static final String CMD_CREATE_USER = "register";
	public static final String CMD_FORGOT_PASSWORD = "forgot_password";
	public static final String CMD_FORGOT_USERNAME = "forgot_username";
	public static final String EMAIL_FROM_ADDRESS = "mail@norkaroots.org";
	public static final boolean ENABLE_OTP = true;
	public static final String DATE_OF_BIRTH_VALIDATION_MESSAGE ="Please enter valid Date of Birth";

}